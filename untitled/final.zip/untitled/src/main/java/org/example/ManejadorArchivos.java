package org.example;

import java.util.List;
public class ManejadorArchivos {
    public static void convertidorJSON(List<PokeApi> p1){
        
    }
}
